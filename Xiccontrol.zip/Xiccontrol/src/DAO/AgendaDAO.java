package DAO;

import Model.Agenda;
import Model.servico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Jaqueline
 */
public class AgendaDAO {
    
     private final Connection con;

    public AgendaDAO() {
        this.con = new Conexao.ConnectionFactory().getConnection();
}

 public void Agendar (Agenda obj) {
        try {
         
            String sql = "INSERT INTO agenda (anome, atelefone, adata, horario, aservico) VALUES(?,?,?,?,?)";

            try (
                    PreparedStatement stmt = con.prepareStatement(sql)) {
                    
                    stmt.setString(1, obj.getNomeCliente());
                    stmt.setString(2, obj.getTelefone());
                    stmt.setString(3, obj.getData());
                    stmt.setString(4, obj.getHorario());
                    stmt.setString(5, obj.getServicoAgenda());
                    stmt.executeUpdate();
                    stmt.close();
            }
            JOptionPane.showMessageDialog(null, "Agendado com sucesso!");

            } catch (SQLException ex) {
                
            Logger.getLogger(ServicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao Agendar: " + ex);
        }
    }
public List <Agenda> listarAgenda() {
        try {

            List <Agenda> lista = new ArrayList<>();
            String sql = "SELECT * FROM xcontrol.agenda";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Agenda obj = new Agenda();
             //   obj.setId(rs.getInt("Id"));
                obj.setNomeCliente(rs.getString("anome"));
                obj.setTelefone(rs.getString("atelefone"));
                obj.setData(rs.getString("adata"));
                obj.setHorario(rs.getString("horario"));
                obj.setServicoAgenda(rs.getString("aservico"));
                boolean add = lista.add(obj);
            }
            return lista;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ops aconteceu o Erro: " + e);
        }
        return null;
    }
}