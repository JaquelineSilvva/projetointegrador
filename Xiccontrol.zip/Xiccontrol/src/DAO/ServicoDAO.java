package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import Model.servico;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Jaqueline
 */
public class ServicoDAO {
   private final Connection con;

    public ServicoDAO() {
        this.con = new Conexao.ConnectionFactory().getConnection();
}

 public void cadastrarServico(servico obj) {
        try {
         
            String sql = "INSERT INTO servico (snome, svalor, scomissao) VALUES(?,?,?)";

            try (
                    PreparedStatement stmt = con.prepareStatement(sql)) {
                    
                    stmt.setString(1, obj.getNomeServico());
                    stmt.setBigDecimal(2, obj.getValorServico());
                    stmt.setBigDecimal(3, obj.getComissao());
                    stmt.executeUpdate();
                    stmt.close();
            }
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");

            } catch (SQLException ex) {
                
            Logger.getLogger(ServicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex);
        }
    }
public List <servico> listarServico() {
        try {

            List <servico> lista = new ArrayList<>();
            String sql = "SELECT * FROM xcontrol.servico";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                servico obj = new servico();
                obj.setId(rs.getInt("Id"));
                obj.setNomeServico(rs.getString("snome"));
                obj.setValorServico(rs.getBigDecimal("svalor"));
                obj.setComissao(rs.getBigDecimal("scomissao"));
                boolean add = lista.add(obj);
            }
            return lista;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ops aconteceu o Erro: " + e);
        }
        return null;
    }
public void alterarServico(servico obj) {

        try {
            
            String sql = "UPDATE servico SET  snome=?, svalor=?, scomissao=? WHERE Id=?";

            try (
                    PreparedStatement stmt = con.prepareStatement(sql)) {
                       
                        stmt.setString(1, obj.getNomeServico());
                        stmt.setBigDecimal(2, obj.getValorServico());
                        stmt.setBigDecimal(3, obj.getComissao());
                        stmt.setInt(4, obj.getId());
                        int executeUpdate = stmt.executeUpdate();
                        stmt.close();
            }
            JOptionPane.showMessageDialog(null, "Atualizado  com sucesso!");

        } catch (SQLException ex) {
            Logger.getLogger(ServicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex);
        }

}
 public void ExcluirServico(servico obj) {

        try {
            String sql = "delete from servico where id= ?";

            try (//    2 passo - conectart o banco de dados e Organizar o Comando sql
                PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setInt(1, obj.getId());
                stmt.executeUpdate();
                stmt.close();
            }
            JOptionPane.showMessageDialog(null, "Exluido com Sucesso com sucesso!");

        } catch (SQLException ex) {
            Logger.getLogger(ServicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        }
 }
}


 