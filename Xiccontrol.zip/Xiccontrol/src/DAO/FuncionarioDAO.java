package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import Model.Funcionario;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Jaqueline
 */
public class FuncionarioDAO {
   private final Connection con;

    public FuncionarioDAO() {
        this.con = new Conexao.ConnectionFactory().getConnection();
}

 public void cadastrarFuncionario(Funcionario obj) {
        try {
         
            String sql = "INSERT INTO funcionario (fnome, femail, ftelefone) VALUES(?,?,?)";

            try (
                    PreparedStatement stmt = con.prepareStatement(sql)) {
                    stmt.setString(1, obj.getNomeFuncionario());
                    stmt.setString(2, obj.getEmail());
                    stmt.setString(3, obj.getTelefone());
                    
                    stmt.executeUpdate();
                    stmt.close();
            }
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");

            } catch (SQLException ex) {
                
            Logger.getLogger(FuncionarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex);
        }
    }
public List <Funcionario> listarFuncionario() {
        try {

            List<Funcionario> lista = new ArrayList<>();
            String sql = "SELECT * FROM xcontrol.funcionario";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Funcionario obj = new  Funcionario();
                obj.setId(rs.getInt("Id"));
                obj.setNomeFuncionario(rs.getString("fnome"));
                obj.setEmail(rs.getString("femail"));
                obj.setTelefone(rs.getString("ftelefone"));
                boolean add = lista.add(obj);
            }
            return lista;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ops aconteceu o Erro: " + e);
        }
        return null;
    }
public void alterarServico(Funcionario obj) {

        try {
            
            String sql = "UPDATE funcionario SET  fnome=?, femail=?, ftelefone=? WHERE Id=?";

            try (
                    PreparedStatement stmt = con.prepareStatement(sql)) {
                       
                        stmt.setString(1, obj.getNomeFuncionario());
                        stmt.setString(2, obj.getEmail());
                        stmt.setString(3, obj.getTelefone());
                        stmt.setInt(4, obj.getId());
                        int executeUpdate = stmt.executeUpdate();
                        stmt.close();
            }
            JOptionPane.showMessageDialog(null, "Atualizado  com sucesso!");

        } catch (SQLException ex) {
            Logger.getLogger(FuncionarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex);
        }

}
 public void ExcluirServico(Funcionario obj) {

        try {
            String sql = "delete from funcionario where id= ?";

            try (//    2 passo - conectart o banco de dados e Organizar o Comando sql
                PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setInt(1, obj.getId());
                stmt.executeUpdate();
                stmt.close();
            }
            JOptionPane.showMessageDialog(null, "Exluido com Sucesso com sucesso!");

        } catch (SQLException ex) {
            Logger.getLogger(FuncionarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        }
 }
}


 