package Model;

/**
 *
 * @author Jaqueline
 */
public class Agenda {
    public int Id;
    public String NomeCliente;
    public String Telefone;
    public String Data;
    public String Horario;
    public String ServicoAgenda;

    /**
     * @return the Id
     */
    public int getId() {
        return Id;
    }

    /**
     * @param Id the Id to set
     */
    public void setId(int Id) {
        this.Id = Id;
    }

    /**
     * @return the NomeCliente
     */
    public String getNomeCliente() {
        return NomeCliente;
    }

    /**
     * @param NomeCliente the NomeCliente to set
     */
    public void setNomeCliente(String NomeCliente) {
        this.NomeCliente = NomeCliente;
    }

    /**
     * @return the Telefone
     */
    public String getTelefone() {
        return Telefone;
    }

    /**
     * @param Telefone the Telefone to set
     */
    public void setTelefone(String Telefone) {
        this.Telefone = Telefone;
    }

    /**
     * @return the Data
     */
    public String getData() {
        return Data;
    }

    /**
     * @param Data the Data to set
     */
    public void setData(String Data) {
        this.Data = Data;
    }

    /**
     * @return the Horario
     */
    public String getHorario() {
        return Horario;
    }

    /**
     * @param Horario the Horario to set
     */
    public void setHorario(String Horario) {
        this.Horario = Horario;
    }

    /**
     * @return the ServicoAgenda
     */
    public String getServicoAgenda() {
        return ServicoAgenda;
    }

    /**
     * @param ServicoAgenda the ServicoAgenda to set
     */
    public void setServicoAgenda(String ServicoAgenda) {
        this.ServicoAgenda = ServicoAgenda;
    }
   
}
