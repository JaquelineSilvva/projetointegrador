package Model;

/**
 *
 * @author Jaqueline
 */
public class Funcionario {
    public int Id;
    public String NomeFuncionario;
    public String Telefone;
    public String Email;

    
    public int getId() {
        return Id;
    }

    
    public void setId(int Id) {
        this.Id = Id;
    }

    
    public String getNomeFuncionario() {
        return NomeFuncionario;
    }

    
    public void setNomeFuncionario(String NomeFuncionario) {
        this.NomeFuncionario = NomeFuncionario;
    }

    
    public String getTelefone() {
        return Telefone;
    }

    
    public void setTelefone(String Telefone) {
        this.Telefone = Telefone;
    }

    
    public String getEmail() {
        return Email;
    }

    
    public void setEmail(String Email) {
        this.Email = Email;
    }

    @Override
    public String toString() {
        return getNomeFuncionario(); //To change body of generated methods, choose Tools | Templates.
    }
    
}
