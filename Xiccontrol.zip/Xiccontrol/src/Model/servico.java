package Model;

import java.math.BigDecimal;

/**
 *
 * @author Jaqueline
 */
public class servico {
    public int Id;
    public String NomeServico;
    public BigDecimal ValorServico;
    public BigDecimal Comissao;

    
    public int getId() {
        return Id;
    }

   
    public void setId(int Id) {
        this.Id = Id;
    }

    
    public String getNomeServico() {
        return NomeServico;
    }

   
    public void setNomeServico(String NomeServico) {
        this.NomeServico = NomeServico;
    }

    
    public BigDecimal getValorServico() {
        return ValorServico;
    }

   
    public void setValorServico(BigDecimal ValorServico) {
        this.ValorServico = ValorServico;
    }

    
    public BigDecimal getComissao() {
        return Comissao;
    }

    
    public void setComissao(BigDecimal Comissao) {
        this.Comissao = Comissao;
    }

    @Override
    public String toString() {
        return getNomeServico(); 
    }
    
}
